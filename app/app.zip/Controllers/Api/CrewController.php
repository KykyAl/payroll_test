<?php

namespace App\Controllers\Api;

use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\RESTful\ResourceController;
use App\Models\CrewApiModel;

class CrewController extends ResourceController
{
    /**
     * Return an array of resource objects, themselves in array format.
     *
     * @return ResponseInterface
     */
    public function index()
    {
        //
    }

    /**
     * Return the properties of a resource object.
     *
     * @param int|string|null $id
     *
     * @return ResponseInterface
     */
    public function show($id = null)
    {
        //
    }

    /**
     * Return a new resource object, with default properties.
     *
     * @return ResponseInterface
     */
    public function new()
    {
        //
    }

    /**
     * Create a new resource object, from "posted" parameters.
     *
     * @return ResponseInterface
     */
    public function create()
    {
        $supir = new CrewApiModel();
        $data = [
            'kode_karyawan' => $this->request->getVar('kode_karyawan'),
            'nama_karyawan' => $this->request->getVar('nama_karyawan'),
            'alamat1' => $this->request->getVar('alamat1'),
            'alamat2' => $this->request->getVar('alamat2'),
            'jabatan' => $this->request->getVar('jabatan'),
            'no_ktp' => $this->request->getVar('no_ktp'),
            'no_sim' => $this->request->getVar('no_sim'),
            'tanggal_masuk' => $this->request->getVar('tanggal_masuk'),
            'qr_code' => $this->request->getVar('qr_code')

        ];

        $save =  $supir->insert($data);

        if ($save) {
            $response = [
                "status" => true,
                "code" => 1,
                "message" => "Berhasil Ditambahkan",
                "data" =>
                $data

            ];
        } else {
            $response = [
                "status" => false,
                "code" => 0,
                "message" => "Gagal ditambahkan",

            ];
        }

        return $this->respondCreated($response);
    }

    /**
     * Return the editable properties of a resource object.
     *
     * @param int|string|null $id
     *
     * @return ResponseInterface
     */
    public function edit($id = null)
    {
        //
    }

    /**
     * Add or update a model resource, from "posted" properties.
     *
     * @param int|string|null $id
     *
     * @return ResponseInterface
     */
    public function update($id = null)
    {
        $supir = new CrewApiModel();
        $data = [

            'nama_karyawan' => $this->request->getVar('nama_karyawan'),
            'alamat1' => $this->request->getVar('alamat1'),
            'alamat2' => $this->request->getVar('alamat2'),
            'jabatan' => $this->request->getVar('jabatan'),
            'no_ktp' => $this->request->getVar('no_ktp'),
            'no_sim' => $this->request->getVar('no_sim'),
            'tanggal_masuk' => $this->request->getVar('tanggal_masuk'),
            'qr_code' => $this->request->getVar('qr_code')

        ];

        $save =  $supir->update($this->request->getVar('kode_karyawan'), $data);
        if ($save) {
            // helper_log("add", "create_jadwal_keberangkatan", json_encode($data));
            $response = [
                "status" => true,
                "code" => 1,
                "message" => "Berhasil Diupdate",
                "data" =>
                $data

            ];
        } else {
            $response = [
                "status" => false,
                "code" => 0,
                "message" => "Gagal duiupdate",

            ];
        }

        return $this->respondCreated($response);
    }

    /**
     * Delete the designated resource object from the model.
     *
     * @param int|string|null $id
     *
     * @return ResponseInterface
     */
    public function delete($id = null)
    {
        $supir = new CrewApiModel();
        $id = $this->request->getGet('id');



        $del = $supir->delete($id);
        if ($del) {

            $response = [
                "status" => true,
                "code" => 1,
                "message" => "Berhasil Dihapus",
                "data" =>
                $id
            ];
        } else {
            $response = [
                "status" => false,
                "code" => 1,
                "message" => "Gagal dihapus"
            ];
        }
        return $this->respondDeleted($response);
    }
}
