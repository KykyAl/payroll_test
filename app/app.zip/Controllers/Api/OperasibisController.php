<?php

namespace App\Controllers\Api;

use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\RESTful\ResourceController;
use App\Models\OperasibisApiModel;

class OperasibisController extends ResourceController
{
    /**
     * Return an array of resource objects, themselves in array format.
     *
     * @return ResponseInterface
     */
    public function index()
    {
        //
    }

    /**
     * Return the properties of a resource object.
     *
     * @param int|string|null $id
     *
     * @return ResponseInterface
     */
    public function show($id = null)
    {
        //
    }

    /**
     * Return a new resource object, with default properties.
     *
     * @return ResponseInterface
     */
    public function new()
    {
        //
    }

    /**
     * Create a new resource object, from "posted" parameters.
     *
     * @return ResponseInterface
     */
    public function create()
    {
        $operasi = new OperasibisApiModel();
        $data = [
            'kode_transaksi' => $this->request->getVar('kode_transaksi'),
            'id_keberangkatan' => $this->request->getVar('id_keberangkatan'),
            'kode_keberangkatan' => $this->request->getVar('kode_keberangkatan'),
            'kota_dari' => $this->request->getVar('kota_dari'),
            'kota_sampai' => $this->request->getVar('kota_sampai'),
            'tanggal' => $this->request->getVar('tanggal'),
            'id_kendaraan' => $this->request->getVar('id_kendaraan'),
            'no_polisi' => $this->request->getVar('no_polisi'),
            'tanggal_berangkat' => $this->request->getVar('tanggal_berangkat'),
            'jam_berangkat' => $this->request->getVar('jam_berangkat'),
            'id_rute' => $this->request->getVar('id_rute'),
            'rute' => $this->request->getVar('rute'),
            'id_supir' => $this->request->getVar('id_supir'),
            'nama_supir' => $this->request->getVar('nama_supir'),
            'id_supir2' => $this->request->getVar('id_supir2'),
            'nama_supir2' => $this->request->getVar('nama_supir2'),
            'id_kernet' => $this->request->getVar('id_kernet'),
            'nama_kernet' => $this->request->getVar('nama_kernet'),
            'keterangan' => $this->request->getVar('keterangan'),
            'created_at' => $this->request->getVar('created_at'),
            'created_by' => $this->request->getVar('created_by')

        ];

        $save =  $operasi->insert($data);


        if ($save == true) {
            // helper_log("add", "create_jadwal_keberangkatan", json_encode($data));

            $response = [
                "status" => true,
                "code" => 1,
                "message" => "Berhasil Ditambahkan",
                "data" =>
                $data

            ];
        } else {
            $response = [
                "status" => false,
                "code" => 0,
                "message" => "Gagal ditambahkan",

            ];
        }

        return $this->respondCreated($response);
    }

    /**
     * Return the editable properties of a resource object.
     *
     * @param int|string|null $id
     *
     * @return ResponseInterface
     */
    public function edit($id = null)
    {
        //
    }

    /**
     * Add or update a model resource, from "posted" properties.
     *
     * @param int|string|null $id
     *
     * @return ResponseInterface
     */
    public function update($id = null)
    {
        $operasi = new OperasibisApiModel();
        $data = [
            'id_keberangkatan' => $this->request->getVar('id_keberangkatan'),
            'kode_keberangkatan' => $this->request->getVar('kode_keberangkatan'),
            'kota_dari' => $this->request->getVar('kota_dari'),
            'kota_sampai' => $this->request->getVar('kota_sampai'),
            'tanggal' => $this->request->getVar('tanggal'),
            'id_kendaraan' => $this->request->getVar('id_kendaraan'),
            'no_polisi' => $this->request->getVar('no_polisi'),
            'tanggal_berangkat' => $this->request->getVar('tanggal_berangkat'),
            'id_rute' => $this->request->getVar('id_rute'),
            'rute' => $this->request->getVar('rute'),
            'id_supir' => $this->request->getVar('id_supir'),
            'nama_supir' => $this->request->getVar('nama_supir'),
            'id_supir2' => $this->request->getVar('id_supir2'),
            'nama_supir2' => $this->request->getVar('nama_supir2'),
            'id_kernet' => $this->request->getVar('id_kernet'),
            'nama_kernet' => $this->request->getVar('nama_kernet'),
            'keterangan' => $this->request->getVar('keterangan'),
            'updated_at' => $this->request->getVar('updated_at'),
            'updated_by' => $this->request->getVar('updated_by')

        ];
        $id = $this->request->getVar('kode_transaksi');
        $dt = $operasi->where('kode_transaksi', $id)->first();


        if (empty($dt)) {
            $response = [
                "status" => false,
                "code" => 0,
                "message" => "Gagal di update data tidak ditemukan",

            ];
        } else {
            $save =  $operasi->update($id, $data);
            if ($save) {
                // helper_log("add", "create_jadwal_keberangkatan", json_encode($data));
                $response = [
                    "status" => true,
                    "code" => 1,
                    "message" => "Berhasil Diupdate",
                    "data" =>
                    $data

                ];
            } else {
                $response = [
                    "status" => false,
                    "code" => 0,
                    "message" => "Gagal duiupdate",

                ];
            }
        }

        return $this->respondCreated($response);
    }

    /**
     * Delete the designated resource object from the model.
     *
     * @param int|string|null $id
     *
     * @return ResponseInterface
     */
    public function delete($id = null)
    {
        $operasi = new OperasibisApiModel();
        $id = $this->request->getGet('kode_transaksi');


        $delete =  $operasi->delete($id);
        if ($delete) {

            $response = [
                "status" => true,
                "code" => 1,
                "message" => "Berhasil Dihapus",
                "data" =>
                $id
            ];
        } else {
            $response = [
                "status" => false,
                "code" => 0,
                "message" => "Gagal Dihapus"

            ];
        }
        return $this->respondDeleted($response);
    }
}
