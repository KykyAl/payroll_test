<?php

namespace App\Controllers\Api;

use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\RESTful\ResourceController;
use App\Models\KaryawanApiModel;

class KaryawanController extends ResourceController
{
    /**
     * Return an array of resource objects, themselves in array format.
     *
     * @return ResponseInterface
     */
    public function index()
    {
        //
    }

    /**
     * Return the properties of a resource object.
     *
     * @param int|string|null $id
     *
     * @return ResponseInterface
     */
    public function show($id = null)
    {
        //
    }

    /**
     * Return a new resource object, with default properties.
     *
     * @return ResponseInterface
     */
    public function new()
    {
        //
    }

    /**
     * Create a new resource object, from "posted" parameters.
     *
     * @return ResponseInterface
     */
    public function create()
    {
        $karyawan = new KaryawanApiModel();
        $data = [
            'id' =>  $this->request->getVar('id'),
            'nik' => $this->request->getVar('nik'),
            'nip' => $this->request->getVar('nip'),
            'nama_lengkap' => $this->request->getVar('nama_lengkap'),
            'email' => $this->request->getVar('email'),
            'alamat' => $this->request->getVar('alamat'),
            'no_telp' => $this->request->getVar('no_telp'),
            'jenis_kelamin' => $this->request->getVar('jenis_kelamin'),
            'tempat_lahir' => $this->request->getVar('tempat_lahir'),
            'tanggal_lahir' => $this->request->getVar('tanggal_lahir'),
            'pendidikan_terakhir' => $this->request->getVar('pendidikan_terakhir'),
            'user_role' => $this->request->getVar('user_role'),
            'akses_booking' => $this->request->getVar('akses_booking'),
            'tanggal_masuk' => $this->request->getVar('tanggal_masuk'),
            'additional' => $this->request->getVar('additional'),
            'user_role' => $this->request->getVar('user_role'),
            'user_id' => $this->request->getVar('user_id'),
            'department_id' => $this->request->getVar('department_id'),
            'photo_profile' => $this->request->getVar('photo_profile'),
            'nama_sekolah' => $this->request->getVar('nama_sekolah'),
            'tipe_komisi' => $this->request->getVar('tipe_komisi'),
            'komisi' => $this->request->getVar('komisi'),
            'makan' => $this->request->getVar('makan'),
            'transport' => $this->request->getVar('transport'),
            'saldo' => $this->request->getVar('saldo'),
            'created_at' => $this->request->getVar('created_at'),
            'created_by' => $this->request->getVar('created_by')

        ];
        $save =  $karyawan->insert($data);


        if ($save == true) {
            // helper_log("add", "create_jadwal_keberangkatan", json_encode($data));

            $response = [
                "status" => true,
                "code" => 1,
                "message" => "Berhasil Ditambahkan",
                "data" =>
                $data

            ];
        } else {
            $response = [
                "status" => false,
                "code" => 0,
                "message" => "Gagal ditambahkan",

            ];
        }

        return $this->respondCreated($response);
    }

    /**
     * Return the editable properties of a resource object.
     *
     * @param int|string|null $id
     *
     * @return ResponseInterface
     */
    public function edit($id = null)
    {
        //
    }

    /**
     * Add or update a model resource, from "posted" properties.
     *
     * @param int|string|null $id
     *
     * @return ResponseInterface
     */
    public function update($id = null)
    {
        $karyawan = new KaryawanApiModel();
        $data = [
            'id' => $this->request->getVar('id'),
            'nik' => $this->request->getVar('nik'),
            'nip' => $this->request->getVar('nip'),
            'nama_lengkap' => $this->request->getVar('nama_lengkap'),
            'email' => $this->request->getVar('email'),
            'alamat' => $this->request->getVar('alamat'),
            'no_telp' => $this->request->getVar('no_telp'),
            'jenis_kelamin' => $this->request->getVar('jenis_kelamin'),
            'tempat_lahir' => $this->request->getVar('tempat_lahir'),
            'tanggal_lahir' => $this->request->getVar('tanggal_lahir'),
            'pendidikan_terakhir' => $this->request->getVar('pendidikan_terakhir'),
            'user_role' => $this->request->getVar('user_role'),
            'akses_booking' => $this->request->getVar('akses_booking'),
            'tanggal_masuk' => $this->request->getVar('tanggal_masuk'),
            'additional' => $this->request->getVar('additional'),
            'user_role' => $this->request->getVar('user_role'),
            'department_id' => $this->request->getVar('department_id'),
            'nama_sekolah' => $this->request->getVar('nama_sekolah'),
            'makan' => $this->request->getVar('makan'),
            'transport' => $this->request->getVar('transport'),
            'saldo' => $this->request->getVar('saldo'),
            'updated_at' => $this->request->getVar('updated_at'),
            'updated_by' => $this->request->getVar('updated_by')

        ];
        $id = $this->request->getVar('id');
        $dt = $karyawan->where('id', $id)->first();


        if (empty($dt)) {
            $response = [
                "status" => false,
                "code" => 0,
                "message" => "Gagal di update data tidak ditemukan",

            ];
        } else {
            $save =  $karyawan->update($id, $data);
            if ($save) {
                // helper_log("add", "create_jadwal_keberangkatan", json_encode($data));
                $response = [
                    "status" => true,
                    "code" => 1,
                    "message" => "Berhasil Diupdate",
                    "data" =>
                    $data

                ];
            } else {
                $response = [
                    "status" => false,
                    "code" => 0,
                    "message" => "Gagal duiupdate",

                ];
            }
        }

        return $this->respondCreated($response);
    }

    /**
     * Delete the designated resource object from the model.
     *
     * @param int|string|null $id
     *
     * @return ResponseInterface
     */
    public function delete($id = null)
    {
        $karyawan = new KaryawanApiModel();
        $id = $this->request->getGet('id');
        $nik = $this->request->getGet('nik');


        $delete =  $karyawan->delete($id);
        if ($delete) {

            $response = [
                "status" => true,
                "code" => 1,
                "message" => "Berhasil Dihapus",
                "data" =>
                $nik
            ];
        } else {
            $response = [
                "status" => false,
                "code" => 0,
                "message" => "Gagal Dihapus"

            ];
        }
        return $this->respondDeleted($response);
    }
}
