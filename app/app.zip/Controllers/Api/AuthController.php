<?php

namespace App\Controllers\Api;

use CodeIgniter\API\ResponseTrait;
use App\Controllers\BaseController;
use CodeIgniter\Shield\Models\UserModel;

class AuthController extends BaseController
{
    use ResponseTrait;
    public function getToken()
    {

        $user = new UserModel();
        $userData = $user->find(auth()->id());
        // $revoce = $userData->revokeAccessTokenBySecret('2745fab6ede014c9bd6cb0a6bac3880601f07a25b2ed4d71b44b397f727988cb');
        $crendentials = [
            'username' => $this->request->getVar('username'),
            'password' => $this->request->getVar('password'),
        ];


        if (auth()->loggedIn()) {
            auth()->logout();
        }


        $loginAttempt = auth()->attempt($crendentials);

        if (!$loginAttempt->isOk()) {
            return $this->fail('invalid Login', 400);
        } else {
            $user = new UserModel();
            $userData = $user->find(auth()->id());
            $token = $userData->generateAccessToken($userData->username);
            $auth_token = $token->raw_token;


            return $this->respond(['status' => true, 'token' => $auth_token]);
        }
    }
}
