<?php

declare(strict_types=1);

/**
 * This file is part of CodeIgniter Shield.
 *
 * (c) CodeIgniter Foundation <admin@codeigniter.com>
 *
 * For the full copyright and license information, please view
 * the LICENSE file that was distributed with this source code.
 */

namespace App\Controllers\Master;

use App\Controllers\BaseController;
use CodeIgniter\Events\Events;
use CodeIgniter\HTTP\RedirectResponse;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Shield\Authentication\Authenticators\Session;
use CodeIgniter\Shield\Entities\User;
use CodeIgniter\Shield\Exceptions\ValidationException;
use CodeIgniter\Shield\Models\UserModel;
use CodeIgniter\Shield\Traits\Viewable;
use CodeIgniter\Shield\Validation\ValidationRules;
use Psr\Log\LoggerInterface;
use App\Models\Master\KaryawanModel;
use App\Models\Master\CrewModel;

/**
 * Class RegisterController
 *
 * Handles displaying registration form,
 * and handling actual registration flow.
 */

class Register extends BaseController
{
    protected $karyawan;
    protected $crew;
    use Viewable;

    public function initController(
        RequestInterface $request,
        ResponseInterface $response,
        LoggerInterface $logger
    ): void {
        parent::initController(
            $request,
            $response,
            $logger
        );
    }



    /**
     * Attempts to register the user.
     */
    public function registerAction()
    {
        $this->karyawan = new KaryawanModel();
        $this->crew = new CrewModel();
        $id = $_REQUEST['id'];
        $tipe = $_REQUEST['tipe'];



        if ($tipe == 'crew') {
            $crew =  $this->crew->find($id);
            $email = $_REQUEST['email'];
            $username =  strtolower(str_replace(' ', '', $crew['nama_karyawan']));
            $id_karyawan = null;
            $id_crew = $crew['kode_karyawan'];
        } else {
            $karyawan =  $this->karyawan->find($id);
            $email = $karyawan['email'];
            $username =  strtolower(str_replace(' ', '', $karyawan['nama_lengkap']));
            $id_karyawan = $karyawan['id'];
            $id_crew = null;
        }
        $data = [
            'username' => $username,
            'email' => $email,
            'password' => 'payroll123',
            'password_confirm' => 'payroll123',
            'role' => 1,
            'access' => '["null"]',
            'id_karyawan' => $id_karyawan,
            'id_crew' => $id_crew

        ];


        $users = $this->getUserProvider();

        // Validate here first, since some things,
        // like the password, can only be validated properly here.
        $rules = $this->getValidationRules();

        if (!$this->validateData($data, $rules, [], config('Auth')->DBGroup)) {

            $response = [
                'response' => 'failed',
                'message' => $this->validator->getErrors()
            ];
            echo json_encode($response);
            die;
        }


        // Save the user
        $allowedPostFields = array_keys($rules);
        $user              = $this->getUserEntity();
        $user->fill($data);

        // Workaround for email only registration/login
        if ($user->username === null) {
            $user->username = null;
        }

        try {
            $users->save($user);
        } catch (ValidationException $e) {
            $response = [
                'response' => 'failed',
                'message' => $users->errors()
            ];
            echo json_encode($response);
            die;
        }

        // To get the complete user object with ID, we need to get from the database
        $user = $users->findById($users->getInsertID());

        // Add to default group
        $users->addToDefaultGroup($user);

        Events::trigger('register', $user);


        $user->activate();


        // Success!
        $response = [
            'response' => 'success',
            'message' => 'User ' . $username . ' berhasil ditambahkan'
        ];
        return json_encode($response);
    }

    /**
     * Returns the User provider
     */
    protected function getUserProvider(): UserModel
    {
        $provider = model(setting('Auth.userProvider'));

        assert($provider instanceof UserModel, 'Config Auth.userProvider is not a valid UserProvider.');

        return $provider;
    }

    /**
     * Returns the Entity class that should be used
     */
    protected function getUserEntity(): User
    {
        return new User();
    }

    /**
     * Returns the rules that should be used for validation.
     *
     * @return array<string, array<string, list<string>|string>>
     */
    protected function getValidationRules(): array
    {
        $rules = new ValidationRules();

        return $rules->getRegistrationRules();
    }
}
