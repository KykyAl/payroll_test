<?php

namespace App\Controllers\Master;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\Master\OperasibisModel;
use App\Libraries\DataTables;

class Operasibis extends BaseController
{
    protected $operasi;
    protected $DataTables;

    public function __construct()
    {
        // Inisialisasi TrayekModel dalam constructor
        $this->operasi = new OperasibisModel();
        $this->request = service('request');
        $this->DataTables = new DataTables();
    }
    public function index(): string
    {
        $userData = auth()->user();
        $uri = service('uri'); // Get the URI service
        $mobile = $this->request->getUserAgent()->isMobile();
        $data = [
            'title' => 'Jadwal Operasi Bus',
            'access' => json_decode($userData->access),
            'segment1' => $uri->getSegment(1),
            'segment2' => $uri->getSegment(2),
            'user' => $userData,
            'mobile' => $mobile
        ];

        return view('master/operasibis/index', $data);
    }
    public function get_data()
    {
        // sql query
        $query = "SELECT * FROM operasi_bis";
        // $where  = array('nama_kategori' => 'Tutorial');
        $where  = null;
        // jika memakai IS NULL pada where sql
        $isWhere = null;
        // $isWhere = 'artikel.deleted_at IS NULL';
        $search = array('kode_transaksi', 'kode_keberangkatan', 'kota_dari', 'kota_sampai', 'id_kendaraan', 'tanggal_berangkat', 'jam_berangkat', 'rute', 'nama_supir', 'nama_supir2', 'nama_kernet');
        echo $this->DataTables->BuildDatatables($query, $where, $isWhere, $search);
    }
    public function read()
    {
        $data = $this->operasi->find($_REQUEST['id']);

        if ($data) {
            $data = array(
                'response' => 'success',
                'data'    => $data,
            );
        } else {
            $data = array(
                'response' => 'failed',
                'messagne' => 'Data tidak ada'
            );
        }
        echo json_encode($data);
    }
}
