<?php

namespace App\Controllers\Master;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\Master\KaryawanModel;
use App\Models\Master\JabatanModel;
use CodeIgniter\Shield\Models\UserModel;
use App\Libraries\DataTables;

class Karyawan extends BaseController
{
    protected $karyawan;
    protected $jabatan;
    protected $DataTables;
    protected $regis;

    public function __construct()
    {
        // Inisialisasi TrayekModel dalam constructor
        $this->karyawan = new KaryawanModel();
        $this->jabatan = new JabatanModel();
        $this->request = service('request');
        $this->DataTables = new DataTables();
    }
    public function index(): string
    {
        $userData = auth()->user();
        $uri = service('uri'); // Get the URI service
        $mobile = $this->request->getUserAgent()->isMobile();
        $data = [
            'title' => 'Karyawan',
            'access' => json_decode($userData->access),
            'segment1' => $uri->getSegment(1),
            'segment2' => $uri->getSegment(2),
            'user' => $userData,
            'mobile' => $mobile
        ];

        return view('master/karyawan/index', $data);
    }
    public function get_data()
    {
        // sql query
        $query = "SELECT k.*,j.nama_jabatan,us.id as iduser FROM karyawan k LEFT JOIN jabatan as j on j.id = k.user_role LEFT JOIN users as us on us.id_karyawan = k.id";
        // $where  = array('nama_kategori' => 'Tutorial');
        $where  = null;
        // jika memakai IS NULL pada where sql
        $isWhere = null;
        // $isWhere = 'artikel.deleted_at IS NULL';
        $search = array('k.id', 'k.nama_lengkap', 'k.nik', 'k.jenis_kelamin', 'k.email', 'j.nama_jabatan');
        echo $this->DataTables->BuildDatatables($query, $where, $isWhere, $search);
    }
    public function read()
    {
        $data = $this->karyawan->find($_REQUEST['id']);
        $jb = $this->jabatan->find();
        if ($data) {
            $data = array(
                'response' => 'success',
                'data'    => $data,
                'jabatan' => $jb
            );
        } else {
            $data = array(
                'response' => 'failed',
                'messagne' => 'Data tidak ada'
            );
        }
        echo json_encode($data);
    }
}
