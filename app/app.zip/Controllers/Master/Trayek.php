<?php

namespace App\Controllers\Master;

use App\Controllers\BaseController;
use App\Models\Master\TrayekModel;
use CodeIgniter\HTTP\Request;

class Trayek extends BaseController
{
    protected $trayekModel;
    protected $request;

    public function __construct()
    {
        // Inisialisasi TrayekModel dalam constructor
        $this->trayekModel = new TrayekModel();
        $this->request = service('request');
    }

    public function index(): string
    {
        $userData = auth()->user();
        $uri = service('uri'); // Get the URI service
        $mobile = $this->request->getUserAgent()->isMobile();

        $data = [
            'title' => 'Trayek',
            'access' => json_decode($userData->access),
            'segment1' => $uri->getSegment(1),
            'segment2' => $uri->getSegment(2),
            'user' => $userData,
            'mobile' => $mobile
        ];

        return view('master/trayek/index', $data);
    }

    public function ajax_list_keberangkatan()
    {
        $list = $this->trayekModel->getKeberangkatan($_POST);
        echo "<pre>" . var_export($list, true);
        die;
    }
    function searchKeberangkatan()
    {

        $postData = $this->request->getPost();
        $response = array();
        $response['token'] = csrf_hash();
        // $searchTerm = $postData['searchTerm'];
        if (!isset($postData['searchTerm'])) {
            $searchTerm = '';
        } else {


            $searchTerm = $postData['searchTerm'];
        }
        $asal = $postData['asal'];
        $tujuan = $postData['tujuan'];
        // Search term
        // Get users
        $response = $this->trayekModel->getAllKeberangkatan($searchTerm, $asal, $tujuan);

        echo json_encode($response);
    }
    function searchKota()
    {

        $postData = $this->request->getPost();
        $response = array();
        $response['token'] = csrf_hash();
        // $searchTerm = $postData['searchTerm'];
        if (!isset($postData['searchTerm'])) {
            $searchTerm = '';
        } else {


            $searchTerm = $postData['searchTerm'];
        }
        // Search term
        // Get users
        $response = $this->trayekModel->getKota($searchTerm);

        echo json_encode($response);
    }

    function getAllTrayek()
    {
        $data = $this->trayekModel->findAll();
        // echo "<pre>" . var_export($data, true);
        // die;
    }
    function create()
    {
        $userData = auth()->user();
        if (in_array('create_master_trayek', json_decode($userData->access)) || $userData->role == 1) {
            $postData = $this->request->getPost();
            if (!empty($postData['keberangkatan'])) {
                $keberangkatan = implode(',', $postData['keberangkatan']);
            } else {
                $keberangkatan = '';
            }
            $data = [
                'kode_trayek' => $postData['kode_trayek'],
                'nama_trayek' => $postData['nama_trayek'],
                'kota_asal' => $postData['kotaAsal'],
                'kota_tujuan' => $postData['kotaTujuan'],
                'keberangkatan' => $keberangkatan,
                'uang_jalan' => floatval(preg_replace("/[^0-9.-]/", "", $postData['uang_jalan'])),
                'uang_perpal' => floatval(preg_replace("/[^0-9.-]/", "", $postData['uang_perpal'])),
                'premi' => floatval(preg_replace("/[^0-9.-]/", "", $postData['premi'])),
                'bonus' => floatval(preg_replace("/[^0-9.-]/", "", $postData['bonus'])),
                'min_setoran' => floatval(preg_replace("/[^0-9.-]/", "", $postData['min_setoran'])),
                'limit_naik_setoran' => floatval(preg_replace("/[^0-9.-]/", "", $postData['limit_naik_setoran'])),
                'max_bonus' => floatval(preg_replace("/[^0-9.-]/", "", $postData['max_bonus'])),
                'bonus_seat' => floatval(preg_replace("/[^0-9.-]/", "", $postData['bonus_seat'])),
                'min_seat' => floatval(preg_replace("/[^0-9.-]/", "", $postData['min_seat'])),
                'target_waktu' => floatval(preg_replace("/[^0-9.-]/", "", $postData['target_waktu'])),
                'bonus_waktu' => floatval(preg_replace("/[^0-9.-]/", "", $postData['bonus_waktu'])),
                'keterangan' => $postData['keterangan'],
                'created_at' => date('Y-m-d H:i:s'),
                'created_by' => $userData->username
            ];

            // echo "<pre>" . var_export($save, true);
            // die;
            $save =  $this->trayekModel->insert($data);
            if ($save) {
                // helper_log("add", "create_jadwal_keberangkatan", json_encode($data));
                $data = array('response' => 'success', 'message' => 'Data berhasil disimpan');
            } else {
                $data = array('response' => 'error', 'message' => 'Data gagal disimpan');
            }
        } else {
            $data = array('response' => 'error', 'message' => 'Anda tidak memiliki akses');
        }
        echo json_encode($data);
    }
    function update()
    {
        $userData = auth()->user();
        if (in_array('update_master_trayek', json_decode($userData->access)) || $userData->role == 1) {
            $postData = $this->request->getPost();
            if (!empty($postData['keberangkatan'])) {
                $keberangkatan = implode(',', $postData['keberangkatan']);
            } else {
                $keberangkatan = '';
            }
            $data = [
                'nama_trayek' => $postData['nama_trayek'],
                'kota_asal' => $postData['kotaAsal'],
                'kota_tujuan' => $postData['kotaTujuan'],
                'keberangkatan' => $keberangkatan,
                'uang_jalan' => floatval(preg_replace("/[^0-9.-]/", "", $postData['uang_jalan'])),
                'uang_perpal' => floatval(preg_replace("/[^0-9.-]/", "", $postData['uang_perpal'])),
                'premi' => floatval(preg_replace("/[^0-9.-]/", "", $postData['premi'])),
                'bonus' => floatval(preg_replace("/[^0-9.-]/", "", $postData['bonus'])),
                'min_setoran' => floatval(preg_replace("/[^0-9.-]/", "", $postData['min_setoran'])),
                'limit_naik_setoran' => floatval(preg_replace("/[^0-9.-]/", "", $postData['limit_naik_setoran'])),
                'max_bonus' => floatval(preg_replace("/[^0-9.-]/", "", $postData['max_bonus'])),
                'bonus_seat' => floatval(preg_replace("/[^0-9.-]/", "", $postData['bonus_seat'])),
                'min_seat' => floatval(preg_replace("/[^0-9.-]/", "", $postData['min_seat'])),
                'target_waktu' => floatval(preg_replace("/[^0-9.-]/", "", $postData['target_waktu'])),
                'bonus_waktu' => floatval(preg_replace("/[^0-9.-]/", "", $postData['bonus_waktu'])),
                'keterangan' => $postData['keterangan'],
                'updated_at' => date('Y-m-d H:i:s'),
                'updated_by' => $userData->username
            ];

            // echo "<pre>" . var_export($save, true);
            // die;
            $save =  $this->trayekModel->update($postData['kode_trayek'], $data);
            if ($save) {
                // helper_log("add", "create_jadwal_keberangkatan", json_encode($data));
                $data = array('response' => 'success', 'message' => 'Data berhasil diupdate');
            } else {
                $data = array('response' => 'error', 'message' => 'Data gagal diupdate');
            }
        } else {
            $data = array('response' => 'error', 'message' => 'Anda tidak memiliki akses');
        }
        echo json_encode($data);
    }
    function delete()
    {
        $userData = auth()->user();
        if (in_array('delete_trayek', json_decode($userData->access)) || $userData->role == 1) {
            // Hapus data
            $result = $this->trayekModel->delete($_REQUEST['id']);


            if ($result) {
                // helper_log("delete", "delete_po_konsumen", json_encode($_REQUEST), '', 'po_konsumen');
                $data = ['response' => 'success', 'message' => 'Data berhasil dihapus', 'last' => $_REQUEST['id']];
            } else {
                $data = ['response' => 'error', 'message' => 'Ada kesalahan pada data, silakan coba lagi nanti'];
            }

            return json_encode($data);
        } else {
            $data = ['response' => 'no_access', 'message' => 'Anda tidak memiliki akses'];
            return json_encode($data);
        }
    }

    function ajax_list_trayek()
    {
        $pharam['draw'] = isset($_REQUEST['draw']) ? $_REQUEST['draw'] : '';
        $keyword = isset($_REQUEST['search']['value']) ? $_REQUEST['search']['value'] : '';
        $start = isset($_REQUEST['start']) ? $_REQUEST['start'] : '';
        $length = isset($_REQUEST['length']) ? $_REQUEST['length'] : '';

        $list = $this->trayekModel->getTrayek($keyword, $start, $length);
        $jmldata = $this->trayekModel->getTrayek($keyword);

        $no = 0;
        $data = [];
        foreach ($list as $stock) {

            $no++;
            $row = array();
            $row[] = $no;
            $row[] = $stock->kode_trayek;
            $row[] = $stock->nama_trayek;
            $row[] = $stock->kota1;
            $row[] = $stock->kota2;
            $data[] = $row;
        }
        $output = array(
            "draw" => intval($pharam['draw']),
            "recordsTotal" => count($jmldata),
            "recordsFiltered" => count($jmldata),
            "data" => $data,
        );
        echo json_encode($output);
    }

    function read()
    {
        $id = $_REQUEST['id'];


        $res = $this->trayekModel->getTrayekById($id);

        if ($res) {
            $data = array('response' => 'success', 'message' => '', 'data' => $res);
            // helper_log("read", "read_pr_bahan_baku", json_encode($res), '', 'pr_bahan_baku');
        } else {
            $data = array('response' => 'error', 'message' => 'Data tidak ditemukan');
        }

        echo json_encode($data);
    }
    function readKeberangkatanIn()
    {
        $data = $this->request->getVar('id');
        $get = $this->trayekModel->getKeberangkatanIn($data);
        echo json_encode($get);
    }
    function read_last_trayek()
    {


        // echo json_encode($this->po->getUniqueId($_POST['tanggal']));
        echo json_encode($this->trayekModel->getUniqueId());
    }
}
