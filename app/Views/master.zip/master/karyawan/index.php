<?= $this->extend('layout/template') ?>

<?= $this->section('title') ?><?= $title ?><?= $this->endSection() ?>

<?= $this->section('main') ?>


<section class="section">
    <div class="section-header">
        <h1><?= $title ?></h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="/">Master</a></div>
            <!-- <div class="breadcrumb-item"><a href="#">Trayek</a></div> -->
            <div class="breadcrumb-item">karyawan</div>
        </div>
    </div>

    <div class="section-body">

        <div class="section-body" style="margin-top: -30px">
            <form id="form">
                <div class="row">
                    <div class="col-12 col-md-12 col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered" id="table_karyawan" style="width: 100%;">
                                        <thead>
                                            <tr>
                                                <th> No</th>
                                                <th> Nama</th>
                                                <th> NIK </th>
                                                <th> Gender </th>
                                                <th> Email </th>
                                                <th> Jabatan </th>
                                                <th> Makan </th>
                                                <th> Transport </th>
                                                <th style="width: 100px;"> User </th>
                                                <th> Aksi </th>
                                            </tr>
                                        </thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>

    </div>
</section>
<!-- Modal Pencarian Gudang-->
<div class="modal fade" id="showModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg  modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title text-white" id="exampleModalLabel">DATA KARYAWAN</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="mb-2">
                    <input type="hidden" class="form-control" name="id" id="id">
                    <div class="row">
                        <div class="col-lg-6">
                            <label class="form-label">NIK</label>
                            <input type="text" class="form-control" readonly name="nik" id="nik" placeholder="NIK">
                        </div>
                        <div class="col-lg-6">
                            <label class="form-label">Nama Lengkap</label>
                            <input type="text" class="form-control" readonly name="nama_lengkap" id="nama_lengkap" placeholder="Nama lengkap">
                        </div>
                    </div>
                </div>
                <div class="mb-2">
                    <div class="row">
                        <div class="col-lg-6">
                            <label class="form-label">Email</label>
                            <input type="email" class="form-control" readonly name="email" id="email" placeholder="Email" required>
                        </div>
                        <div class="col-lg-6">
                            <label class="form-label">No Telp</label>
                            <div class="input-group mb-2">
                                <span class="input-group-text">
                                    +62
                                </span>
                                <input type="text" class="form-control" readonly name="no_telp" id="no_telp" onkeyup="numericOnly(this)" onblur="numericOnly(this)" placeholder="No Telp" autocomplete="off">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mb-2">
                    <div class="row">
                        <div class="col-lg-3">
                            <label class="form-label">Tempat/Tanggal lahir</label>
                            <input type="text" readonly class="form-control" name="tempat_lahir" id="tempat_lahir" placeholder="Tempat lahir">
                        </div>
                        <div class="col-lg-3">
                            <label class="form-label text-white">Tanggal lahir</label>
                            <input type="date" readonly class="form-control" name="tanggal_lahir" id="tanggal_lahir" placeholder="Tanggal lahir">
                        </div>
                        <div class="col-lg-6">
                            <label class="form-label">Jenis Kelamin</label>
                            <select class="form-control" name="jenis_kelamin" readonly id="jenis_kelamin">
                                <option value="1">Laki-Laki</option>
                                <option value="2">Perempuan</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="mb-2">
                    <div class="row">
                        <div class="col-lg-12">
                            <label class="form-label">Alamat Lengkap</label>
                            <textarea class="form-control" readonly name="alamat" id="alamat" rows="2" placeholder="Alamat lengkap.."></textarea>
                        </div>
                    </div>
                </div>

                <div class="mb-2">
                    <div class="row">
                        <div class="col-lg-6">
                            <label class="form-label">Pendidikan Terakhir</label>
                            <select readonly class="form-control" name="pendidikan_terakhir" id="pendidikan_terakhir">
                                <option value="strata2">Strata 2</option>
                                <option value="strata1">Strata 1</option>
                                <option value="sma">SMA</option>
                                <option value="smp">SMP</option>
                                <option value="-">-</option>
                            </select>
                        </div>
                        <div class="col-lg-6">
                            <label class="form-label">Nama Universitas / Sekolah</label>
                            <input type="text" class="form-control" readonly name="nama_sekolah" id="nama_sekolah" placeholder="Nama Univ / Sekolah Terakhir">
                        </div>
                    </div>
                </div>
                <div class="mb-2">
                    <div class="row">
                        <div class="col-lg-12">
                            <label class="form-label">Additional information</label>
                            <textarea class="form-control" value="" readonly name="additional" id="additional" rows="2"></textarea>
                        </div>
                    </div>
                </div>
                <hr>
                <h2 class="text-center"><span class="badge bg-warning text-dark">DATA KARYAWAN</span></h3>
                    <hr>
                    <div class="mb-2">
                        <div class="row">
                            <div class="col-lg-6">
                                <label class="form-label">NIP</label>
                                <div class="input-group">
                                    <input readonly type="text" class="form-control" placeholder="NIP" name="nip" id="nip" aria-label="Recipient's username" aria-describedby="button-addon2">
                                    <button class="btn btn-danger ms-auto" data-bs-toggle="tooltip" data-bs-placement="top" title="Generate random NIP" type="button">
                                        <div class="text-center ms-auto">
                                            <svg xmlns="http://www.w3.org/2000/svg" class="ms-auto icon icon-tabler icon-tabler-rotate" width="30" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                                <path stroke="none" d="M0 0h24v24H0z" fill="none"></path>
                                                <path d="M19.95 11a8 8 0 1 0 -.5 4m.5 5v-5h-5"></path>
                                            </svg>
                                        </div>
                                    </button>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <label class="form-label">Tanggal Masuk</label>
                                <input type="date" readonly class="form-control" name="tanggal_masuk" id="tanggal_masuk">
                            </div>
                        </div>
                    </div>
                    <div class="mb-2">
                        <div class="row">
                            <div class="col-lg-6">
                                <label class="form-label">Jabatan</label>
                                <select class="form-control" readonly name="jabatan" class="jabatan" id="jabatan">
                                    <option value="">-</option>

                                </select>
                            </div>
                            <div class="col-lg-6">
                                <br>
                                <br>
                                <div class="form-check">
                                    <input class="form-check-input akses_booking" name="akses_booking" type="checkbox" id="akses_booking">
                                    <label class="form-check-label" for="open_transit">
                                        <strong>Akses Booking</strong>
                                    </label>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <label class="form-label">Saldo</label>
                                <input type="text" readonly class="form-control currency_no_decimal" style="text-align: right;" name="saldo" id="saldo">

                            </div>
                            <div class="col-lg-6">
                                <label class="form-label">Photo</label>
                                <input type="file" readonly name="images" id="images" class="form-control" />
                                <!-- <input type="file" class="form-control" name="file" id="file"> -->
                            </div>
                            <div class="col-lg-6">
                                <label class="form-label">Makan</label>
                                <input type="text" readonly class="form-control currency_no_decimal" style="text-align: right;" name="makan" id="makan">

                            </div>
                            <div class="col-lg-6">
                                <label class="form-label">Transport</label>
                                <input type="text" readonly class="form-control currency_no_decimal" style="text-align: right;" name="transport" id="transport">

                            </div>
                        </div>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" id="close_trayek">Close</button>

            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        tabel = $('#table_karyawan').DataTable({
            "processing": true,
            // "responsive": true,
            "serverSide": true,
            "ordering": true, // Set true agar bisa di sorting
            "order": [
                [0, 'asc']
            ], // Default sortingnya berdasarkan kolom / field ke 0 (paling pertama)
            "ajax": {
                "url": "<?= site_url('master/karyawan/data'); ?>", // URL file untuk proses select datanya
                "type": "POST",
                // csrf datatable
                // "data": function(d) {
                //     d.<?= csrf_token() ?> = hash;
                // }
            },
            "deferRender": true,
            "aLengthMenu": [
                [10, 50, 100],
                [10, 50, 100]
            ], // Combobox Limit
            "columns": [{
                    "data": 'id',
                    "orderable": false,
                    "visible": false,
                    render: function(data, type, row, meta) {
                        return meta.row + meta.settings._iDisplayStart + 1;
                    }
                }, {
                    "data": 'nama_lengkap',
                    "render": function(data, type, row, meta) {
                        return row.nama_lengkap + '<br> (' + row.nik + ')';
                    }
                },
                {
                    "visible": false,
                    "data": "nik"
                },
                {
                    "data": "jenis_kelamin",
                    "visible": false,
                    "render": function(data, type, row, meta) {

                        if (row.jenis_kelamin == 1) {
                            return 'Laki-Laki'
                        } else if (row.jenis_kelamin == 2) {
                            return 'Perempuan'

                        } else {
                            return row.jenis_kelamin

                        }
                    }
                },
                {
                    "data": "email"
                },
                {
                    "data": "nama_jabatan"
                },

                {
                    "data": "makan",
                    "visible": false,
                    "render": function(data, type, row, meta) {

                        return Number(row.makan).toLocaleString();
                    }
                },
                {
                    "data": "transport",
                    "visible": false,
                    "render": function(data, type, row, meta) {

                        return Number(row.transport).toLocaleString();
                    }
                },
                {
                    "data": null,
                    "render": function(data, type, row, meta) {
                        if (row.iduser == null) {

                            return ' <button type="button" value = "' + row.nik + '"class="btn btn-warning btn-sm" style="width:80px" id="btnAddUser">Buat User</button>';
                        } else {
                            return '<i class="fa fa-user-check" style="color:green;"></i>';
                        }
                    }
                },
                {
                    "data": null,
                    "render": function(data, type, row, meta) {
                        return ' <button type="button" value = "' + row.nik + '"class="btn btn-primary btn-sm" id="btnShow"><i class="fas fa-eye"></i></button>';
                    }
                },
                // {
                //     "data": "id_kategori", // Tampilkan kolomid_kategori pada table kategori
                //     "render": function(data, type, row, meta) {
                //         return '<a href="show/' + data + '">Show</a>';
                //     }
                // },
            ],
        });


        $('#close_trayek').on('click', function(e) {
            $('#showModal').modal('hide');

        })








    })



    $(document).on('click', '#btnAddUser', function(e) {


        $.ajax({
            url: "<?= base_url('master/karyawan/register') ?>",
            data: {
                id: $(this).val(),
                tipe: 'karyawan'

            },
            type: "POST",
            dataType: "JSON",
            success: function(res) {
                if (res.response == 'success') {

                    toastr.success(res.message)
                } else if (res.response == 'failed') {
                    $.each(res.message, function(index, message) {
                        toastr.error(message)
                    });
                } else {
                    warningToast('Error', 'Something wrong! please try again', 1);
                }
            }
        })
    })
    $(document).on('click', '#btnShow', function(e) {


        $.ajax({
            url: "<?= base_url('master/karyawan/show') ?>",
            data: {
                id: $(this).val(),

            },
            type: "POST",
            dataType: "JSON",
            success: function(res) {
                if (res.response == 'success') {

                    $('#showModal').modal('show')
                    $('#nik').val(res.data.nik);
                    $('#nama_lengkap').val(res.data.nama_lengkap);
                    $('#email').val(res.data.email);
                    $('#tempat_lahir').val(res.data.tempat_lahir);
                    $('#tanggal_lahir').val(res.data.tanggal_lahir);
                    $('#no_telp').val(res.data.no_telp);
                    $('#jenis_kelamin').val(res.data.jenis_kelamin);
                    $('#alamat').val(res.data.alamat);
                    $('#pendidikan_terakhir').val(res.data.pendidikan_terakhir);
                    $('#nama_sekolah').val(res.data.nama_sekolah);
                    $('#additional').val(res.data.additional);
                    $('#nip').val(res.data.nip);
                    $('#tanggal_masuk').val(res.data.tanggal_masuk);
                    $('#jabatan').empty()
                    $.each(res.jabatan, function(index, jabatan) {
                        $('#jabatan').append('<option value="' + jabatan.id + '">' + jabatan.nama_jabatan + '</option>');
                    });
                    $('#jabatan').val(res.data.user_role);
                    $('#saldo').val(res.data.saldo).formatCurrency({
                        colorize: true,
                        negativeFormat: '-%s%n',
                        roundToDecimalPlace: 0
                    });
                    $('#makan').val(res.data.makan).formatCurrency({
                        colorize: true,
                        negativeFormat: '-%s%n',
                        roundToDecimalPlace: 0
                    });
                    $('#transport').val(res.data.transport).formatCurrency({
                        colorize: true,
                        negativeFormat: '-%s%n',
                        roundToDecimalPlace: 0
                    });
                    if (res.data.akses_booking == 12) {
                        $('#akses_booking').prop('checked', true)
                    } else {
                        $('#akses_booking').prop('checked', false)

                    }

                    // $('.modal-title').text('Edit Data Jadwal Operasi Bis');
                } else if (res.response == 'failed') {
                    failedToast(res.response, res.message, 5);
                } else {
                    warningToast('Error', 'Something wrong! please try again', 1);
                }
            }
        })
    })
</script>

<?= $this->endSection() ?>