<?= $this->extend('layout/template') ?>

<?= $this->section('title') ?>Trayek<?= $this->endSection() ?>

<?= $this->section('main') ?>


<section class="section">
    <div class="section-header">
        <h1><?= $title ?></h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="/">Master</a></div>
            <!-- <div class="breadcrumb-item"><a href="#">Trayek</a></div> -->
            <div class="breadcrumb-item">Trayek</div>
        </div>
    </div>

    <div class="section-body">

        <div class="section-body" style="margin-top: -30px">
            <form id="form">
                <div class="row">
                    <div class="col-12 col-md-12 col-lg-12">
                        <div class="card">
                            <div class="card-body">

                                <div id="kiri">

                                    <div class="form-row">
                                        <div class="col-md-3">
                                            <label for="kode_kategori" class="judul">Kode Trayek</label>
                                            <div class="input-group">
                                                <input type="text" class="form-control " id="kode_trayek" placeholder="Kode trayek" name="kode_trayek" required>
                                                <span class="help-block"></span>

                                                <!-- <button type="button" class="btn btn-outline-danger btn-lg rounded" data-toggle="modal" data-target="#searchModal" name="cari" id="cari"> <i class="fas fa-search"></i> </button> -->
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <label for="kode_kategori" class="judul">Nama Trayek</label>
                                            <div class="input-group">
                                                <input type="text" class="form-control " id="nama_trayek" placeholder="Nama trayek" name="nama_trayek" required>
                                                <span class="help-block"></span>

                                                <!-- <button type="button" class="btn btn-outline-danger btn-lg rounded" data-toggle="modal" data-target="#searchModal" name="cari" id="cari"> <i class="fas fa-search"></i> </button> -->
                                            </div>
                                        </div>
                                        <div class="col-md-3" id="selectdarikota">

                                            <label for="kode_kategori" class="judul">Dari Kota</label>
                                            <select class="js-example-basic form-select select2" name="kotaAsal" id="kotaAsal" class="form-control">
                                            </select>
                                        </div>
                                        <div class="col-md-3" id="selectsampaikota">

                                            <label for="kode_kategori" class="judul">Sampai Kota</label>
                                            <select class="js-example-basic form-select select2" name="kotaTujuan" id="kotaTujuan" class="form-control">
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-row">


                                        <div class="col-md-9" id="selectkeberangkatan">
                                            <label for="keberangkatan">Keberangkatan</label>
                                            <div class="form-group">
                                                <div>
                                                    <select class="js-example-basic-multiple form-select select2" name="keberangkatan[]" id="keberangkatan" class="form-control" multiple="multiple">
                                                    </select>
                                                    <!-- <label class="form-check form-check-inline">
                                                        <input class="form-check-input" type="checkbox" name="all_keberangkatan" id="all_keberangkatan">
                                                        <span class="form-check-label">Pilih semua agen</span>
                                                    </label> -->
                                                </div>

                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <label for="kode_kategori" class="judul">Uang Jalan</label>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">Rp</div>
                                                </div>
                                                <input type="text" class="form-control currency_notdecimal" style="text-align: right;" id="uang_jalan" placeholder="uang jalan" name="uang_jalan" required>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="form-row">

                                        <div class="col-md-3">
                                            <label for="kode_kategori" class="judul">Uang Perpal</label>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">Rp</div>
                                                </div>
                                                <input type="text" class="form-control currency_notdecimal" style="text-align: right;" id="uang_perpal" placeholder="uang perpal" name="uang_perpal" required>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <label for="kode_kategori" class="judul">Premi</label>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">Rp</div>
                                                </div>
                                                <input type="text" class="form-control currency_notdecimal" style="text-align: right;" id="premi" placeholder="premi" name="premi" required>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <label for="kode_kategori" class="judul">Bonus</label>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">Rp</div>
                                                </div>
                                                <input type="text" class="form-control currency_notdecimal" style="text-align: right;" id="bonus" placeholder="bonus" name="bonus" required>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <label for="kode_kategori" class="judul">Min Setoran</label>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">Rp</div>
                                                </div>
                                                <input type="text" class="form-control currency_notdecimal" style="text-align: right;" id="min_setoran" name="min_setoran" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-row">

                                        <div class="col-md-3">
                                            <label for="kode_kategori" class="judul">Limit Kenaikan Setoran</label>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">Rp</div>
                                                </div>
                                                <input type="text" class="form-control currency_notdecimal" style="text-align: right;" id="limit_naik_setoran" placeholder="" name="limit_naik_setoran" required>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <label for="kode_kategori" class="judul">Max Bonus</label>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">Rp</div>
                                                </div>
                                                <input type="text" class="form-control currency_notdecimal" style="text-align: right;" id="max_bonus" placeholder="max_bonus" name="max_bonus" required>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <label for="kode_kategori" class="judul">Bonus Seats</label>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">Rp</div>
                                                </div>
                                                <input type="text" class="form-control currency_notdecimal" style="text-align: right;" id="bonus_seat" placeholder="bonus_seat" name="bonus_seat" required>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <label for="kode_kategori" class="judul">Min Seats</label>
                                            <div class="input-group">
                                                <input type="text" class="form-control currency_notdecimal" style="text-align: right;" id="min_seat" name="min_seat" required>
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">Seats</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-row">

                                        <div class="col-md-3">
                                            <label for="kode_kategori" class="judul">Target Waktu</label>
                                            <div class="input-group">
                                                <input type="text" class="form-control currency_notdecimal" style="text-align: right;" id="target_waktu" placeholder="" name="target_waktu" required>
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">Jam</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <label for="kode_kategori" class="judul">Bonus Waktu</label>
                                            <div class="input-group">
                                                <div class="input-group-prepend">
                                                    <div class="input-group-text">Rp</div>
                                                </div>
                                                <input type="text" class="form-control currency_notdecimal" style="text-align: right;" id="bonus_waktu" placeholder="bonus_waktu" name="bonus_waktu" required>
                                            </div>
                                        </div>


                                    </div>
                                    <div class="form-row">
                                        <div class="col-md-12">
                                            <label for="kode_kategori" class="judul">Keterangan</label>
                                            <div class="input-group">
                                                <textarea type="text" class="form-control" style="height: 200px;" id="keterangan" placeholder="keterangan" name="keterangan" required></textarea>
                                            </div>
                                        </div>

                                    </div>



                                    <div class="mt-5">
                                        <!-- <button type="button" class="btn btn-danger browse" id="btnPDF">Cetak</button> -->
                                        <?php if ((in_array('create_master_trayek', $access)) || $user->role == 1) { ?>
                                            <button type="button" class="btn btn-primary" id="btnSave">Simpan</button>
                                        <?php } ?>
                                        <?php if ((in_array('update_master_trayek', $access)) || $user->role == 1) { ?>
                                            <button type="button" class="btn btn-info ml-1 mr-1" id="btnUpdate">Update</button>
                                        <?php } ?>
                                        <?php if ((in_array('delete_master_trayek', $access)) || $user->role == 1) { ?>
                                            <button type="button" class="btn btn-danger ml-1 mr-1" id="btnHapus">Hapus</button>
                                        <?php } ?>
                                        <button type="button" class="btn btn-secondary ml-1 mr-1" id="btnBatal">Batal</button>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>

    </div>
</section>
<!-- Modal Pencarian Gudang-->
<div class="modal fade" id="trayekModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl  modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title text-white" id="exampleModalLabel">CARI TRAYEK</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body table-responsive ">
                <table class="table table-sm" width="100%" id="table_trayek">
                    <thead>
                        <tr class="bg-warning">

                            <th scope="col">No</th>
                            <th scope="col">Kode Trayek</th>
                            <th scope="col">Nama Trayek</th>
                            <th scope="col">Asal</th>
                            <th scope="col">Tujuan</th>

                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" id="close_trayek">Close</button>
                <button type="button" class="btn btn-primary" id="ok_trayek">OK</button>
            </div>
        </div>
    </div>
</div>
<script>
    function initialize() {
        $('#kode_trayek').focus()
        $('#btnSave').show();
        $('#btnUpdate, #btnHapus, #btnUpdateStock,#btnRequest,#btnPrint').hide();
        $('input:text, textarea').val('');
        $('#uang_jalan').val(0);
        $('#uang_perpal').val(0);
        $('#premi').val(0);
        $('#bonus').val(0);
        $('#limit_naik_setoran').val(0);
        $('#max_bonus').val(0);
        $('#bonus_seat').val(0);
        $('#min_setoran').val(0);
        $('#min_seat').val(0);
        $('#target_waktu').val(0);
        $('#bonus_waktu').val(0);
        nomorbaru()
        $('input:checkbox').prop('checked', false);
        $('#keberangkatan').val([]).trigger('change');
        $('.select2').val(null).trigger('change');

    }

    function read_kode(id = '') {
        if (id == '') {
            $('#kode_trayek').focus();
        } else {
            $.ajax({
                url: "<?= base_url('master/trayek/read') ?>",
                type: "POST",
                dataType: "JSON",
                data: {
                    "id": id,

                },
                success: function(res) {
                    if (res.response == 'success') {

                        var obj = 0;
                        $('#keberangkatan').val([]).trigger('change');
                        $('.select').val(null).trigger('change');
                        $('#kode_trayek').val(res.data.kode_trayek);
                        $('#nama_trayek').val(res.data.nama_trayek);
                        let option
                        option = new Option(res.data.kota1, res.data.kota_asal, true, true);
                        console.log(option)
                        $('#kotaAsal').append(option).trigger('change');
                        option = new Option(res.data.kota2, res.data.kota_tujuan, true, true);
                        $('#kotaTujuan').append(option).trigger('change');
                        if (res.data.keberangkatan != null || res.data.keberangkatan != '') {
                            let keberangkatan = res.data.keberangkatan.split(',');
                            console.log(keberangkatan)
                            $.ajax({
                                url: "<?= base_url('master/trayek/readKeberangkatanIn') ?>",
                                data: {
                                    id: keberangkatan
                                },
                                dataType: "JSON",
                                type: "POST",
                                success: function(res4) {
                                    $.each(res4, function(i, j) {
                                        option = new Option(j.kode_keberangkatan, j.id, true, true);
                                        $('#keberangkatan').append(option).trigger('change');
                                    })
                                }
                            })
                        }
                        $('#uang_jalan').val(res.data.uang_jalan).formatCurrency({
                            colorize: true,
                            negativeFormat: '-%s%n',
                            roundToDecimalPlace: 0
                        });
                        $('#uang_perpal').val(res.data.uang_perpal).formatCurrency({
                            colorize: true,
                            negativeFormat: '-%s%n',
                            roundToDecimalPlace: 0
                        });
                        $('#premi').val(res.data.premi).formatCurrency({
                            colorize: true,
                            negativeFormat: '-%s%n',
                            roundToDecimalPlace: 0
                        });
                        $('#bonus').val(res.data.bonus).formatCurrency({
                            colorize: true,
                            negativeFormat: '-%s%n',
                            roundToDecimalPlace: 0
                        });
                        $('#min_setoran').val(res.data.min_setoran).formatCurrency({
                            colorize: true,
                            negativeFormat: '-%s%n',
                            roundToDecimalPlace: 0
                        });
                        $('#limit_naik_setoran').val(res.data.limit_naik_setoran).formatCurrency({
                            colorize: true,
                            negativeFormat: '-%s%n',
                            roundToDecimalPlace: 0
                        });
                        $('#max_bonus').val(res.data.max_bonus).formatCurrency({
                            colorize: true,
                            negativeFormat: '-%s%n',
                            roundToDecimalPlace: 0
                        });
                        $('#bonus_seat').val(res.data.bonus_seat).formatCurrency({
                            colorize: true,
                            negativeFormat: '-%s%n',
                            roundToDecimalPlace: 0
                        });
                        $('#min_seat').val(res.data.min_seat).formatCurrency({
                            colorize: true,
                            negativeFormat: '-%s%n',
                            roundToDecimalPlace: 0
                        });
                        $('#target_waktu').val(res.data.target_waktu).formatCurrency({
                            colorize: true,
                            negativeFormat: '-%s%n',
                            roundToDecimalPlace: 0
                        });
                        $('#bonus_waktu').val(res.data.bonus_waktu).formatCurrency({
                            colorize: true,
                            negativeFormat: '-%s%n',
                            roundToDecimalPlace: 0
                        });
                        $('#keterangan').val(res.data.keterangan);








                        $('#btnSave').hide();
                        $('#btnUpdate').show();
                        $('#btnHapus').show();
                        $('#btnPrint').show();
                        $('#trayekModal').modal('hide')
                        $('#nama_trayek').focus()
                    } else if (res.response == 'error') {
                        $('#nama_trayek').focus()




                    }
                }
            })
        }
    }

    function nomorbaru() {
        ;
        $.ajax({
            url: "<?= base_url('master/trayek/read_last_trayek') ?>",
            type: "GET",
            // data: {
            //     tanggal: tgl,
            //     // kode_lokasi: $('#kode_lokasi').val()
            // },
            dataType: "JSON",
            success: function(result) {


                if (result === null || result == undefined) {

                    $('#kode_trayek').val('TR-0001');

                } else {

                    // String awal
                    var str = result;

                    // Mengonversi string ke bilangan bulat dan menambahkannya
                    var num = parseInt(str, 10) + 1;

                    // Mengonversi kembali ke string dengan tambahan nol di depan jika perlu
                    var lastid = num.toString().padStart(str.length, '0');
                    var no_inv = 'TR-' + lastid;

                    $('#kode_trayek').val(no_inv);
                }
            }
        })
    }

    function urut() {
        var z = 0;
        var x = 1;
        for (; z < Number($('#baris-trayek').val()); z++) {
            if ($('#po-' + z + '-kode_keberangkatan').val() != null) {
                $('#po-' + z + '-no_urut').val(x);
                x++;
            }

        }
    }

    function getKeberangkatan() {
        $("#keberangkatan").select2({
            placeholder: 'Pilih keberangkatan',
            dropdownParent: $("#selectkeberangkatan"),
            allowClear: true,
            ajax: {
                url: '<?= base_url('master/trayek/searchKeberangkatan') ?>',
                type: "POST",
                dataType: 'json',
                delay: 250,
                data: function(params) {
                    return {
                        searchTerm: params.term,
                        asal: $('#kotaAsal').val(),
                        tujuan: $('#kotaTujuan').val() // search term
                    };
                },
                processResults: function(response) {
                    return {
                        results: response
                    };
                },
            }

        });
    }

    function getKotaAsal() {
        $('#kotaAsal').select2({
            placeholder: 'Pilih Kota Asal',
            dropdownParent: $('#selectdarikota'),
            allowClear: false,
            ajax: {
                url: '<?= base_url('master/trayek/searchKota') ?>',
                type: "POST",
                dataType: "JSON",
                delay: 250,
                data: function(params) {
                    return {
                        searchTerm: params.term
                    };
                },
                processResults: function(response) {
                    return {
                        results: response
                    };
                },
                cache: true
            }
        })


        $('#kotaTujuan').select2({
            placeholder: 'Pilih Sampai',
            dropdownParent: $('#selectsampaikota'),
            allowClear: false,
            ajax: {
                url: '<?= base_url('master/trayek/searchKota') ?>',
                type: "POST",
                dataType: "JSON",
                delay: 250,
                data: function(params) {
                    return {
                        searchTerm: params.term
                    };
                },
                processResults: function(response) {
                    return {
                        results: response
                    };
                },
                cache: true
            }
        })
    }
    $(document).ready(function() {
        initialize()
        $('#kode_trayek').focus()
        $(document).ready(function() {
            getKeberangkatan()
            getKotaAsal()
        })
        $('#close_trayek').on('click', function(e) {
            $('#trayekModal').modal('hide');
            $('#kode_trayek').focus();
        })

        $('#kode_trayek').on('dblclick', function(e) {


            $('#trayekModal').modal('show');


        })
        $('#kode_trayek').on('keydown', function(e) {
            var id = $(this).attr('id');
            var no = id.split('-')
            // $('#id_baris').val(no[1])
            if (e.which === 13) {
                if ($(this).val() == '') {

                    $('#trayekModal').modal('show');
                } else {
                    read_kode($(this).val())
                }
            }
        })
        $('#nama_trayek').on('keydown', function(e) {
            if (e.which === 13) {
                if ($(this).val() == '') {

                    $('#nama_trayek').focus()
                } else {
                    $('#kotaAsal').focus()
                }
            }
        })
        $('#kotaAsal').on('keydown', function(e) {
            if (e.which === 13) {
                if ($(this).val() == '') {

                    $('#kotaTujuan').focus()
                } else {
                    $('#keberangkatan').focus()
                }
            }
        })
        $('#keberangkatan').on('keydown', function(e) {
            if (e.which === 13) {
                if ($(this).val() == '') {

                    $('#keberangkatan').focus()
                } else {
                    $('#uang_jalan').focus()
                }
            }
        })
        $('#uang_jalan').on('keydown', function(e) {
            if (e.which === 13) {
                if ($(this).val() == '') {

                    $('#uang_jalan').focus()
                } else {
                    $('#uang_perpal').focus()
                }
            }
        })
        $('#uang_perpal').on('keydown', function(e) {
            if (e.which === 13) {
                if ($(this).val() == '') {

                    $('#uang_perpal').focus()
                } else {
                    $('#premi').focus()
                }
            }
        })
        $('#premi').on('keydown', function(e) {
            if (e.which === 13) {
                if ($(this).val() == '') {

                    $('#premi').focus()
                } else {
                    $('#bonus').focus()
                }
            }
        })
        $('#trayekModal').on('hide.bs.modal', function(e) {
            table_trayek.destroy();
            $('#kode_trayek').focus();

        })
        $('#trayekModal').on('shown.bs.modal', function(e) {

            table_trayek = $('#table_trayek').DataTable({
                keys: {
                    columns: [1]
                },
                "processing": true, //Feature control the processing indicator.
                "serverSide": true, //Feature control DataTables' servermside processing mode.
                "iDisplayLength": 15,
                "lengthChange": false,
                "ordering": false,
                "scrollY": "45%",
                "scrollCollapse": true,
                "paging": true,
                "ajax": {
                    "url": "<?= base_url('master/trayek/ajax_list_trayek') ?>",
                    "type": "POST",
                    "dataType": "json",
                    "dataSrc": function(jsonData) {
                        return jsonData.data;
                    },
                },
                "columnDefs": [{
                        "targets": [0],
                        "orderable": true, //set not orderable
                    },
                    {
                        "targets": [1],
                        "visible": true,

                    },

                    // {
                    //     "targets": [5],
                    //     "visible": false,

                    // },
                ],

                "drawCallback": function(settings) {
                    table_trayek.cell(':eq(1)').focus();
                    $('ul.pagination', table_trayek.table().container()).removeClass('pagination').addClass('pagination pagination-sm');
                }
            });

            table_trayek
                .on('key', function(e, datatable, key, cell, originalEvent) {
                    if (key === 13) {
                        // Mengambil data dari kolom saat ini (kolom yang dipilih)
                        var rowData = table_trayek.row(cell.index().row).data();

                        read_kode(rowData[1]);
                    }
                })

            table_trayek.on('key-focus', function(e, datatable, cell) {
                var rowData = table_trayek.row(cell.index().row).data();

                $('#ok_trayek').data('kode', rowData[1]);


            });
            // Event handler untuk tombol "OK"
            $('#ok_trayek').on('click', function() {

                read_kode($(this).data('kode'));





            });


            $('div.dataTables_filter input', table_trayek.table().container()).focus();
        })

    })


    $(document).on('click', '#btnSave', function(e) {

        e.preventDefault();

        $('#btnSave').text('saving...'); //change button text
        $('#btnSave').attr('disabled', true); //set button disable

        // ajax adding data to database
        $.ajax({
            url: "<?= base_url('master/trayek/create') ?>",
            type: "POST",
            data: $('#form').serialize(),
            dataType: "json",
            success: function(res) {
                // e.preventDefault();

                if (res.response == 'success') {
                    toastr.success(res.message)
                    initialize();

                } else if (res.response == 'found') {
                    toastr.warning('Kode Trayek sudah ada, silahkan diganti')
                } else if (res.response == 'gagal') {
                    toastr.warning('Ada masalah pada server, silahkan dicoba lagi')
                } else if (res.response == 'no_access') {
                    toastr.warning(res.message)
                } else {
                    toastr.error(res.message)

                }

                $('#btnSave').text('Simpan'); //change button text
                $('#btnSave').attr('disabled', false); //set button enable
            },
            error: function(jqXHR, textStatus, errorThrown) {
                // toastr.error(res.message)
                $('#btnSave').text('Simpan'); //change button text
                $('#btnSave').attr('disabled', false); //set button enable

            }
        });
    })
    $(document).on('click', '#btnUpdate', function(e) {
        e.preventDefault();

        $('#btnUpdate').text('updating...');
        $('#btnUpdate').attr('disabled', true);
        // ajax adding data to database
        $.ajax({
            url: "<?php echo site_url('master/trayek/update') ?>",
            type: "POST",
            data: $('#form').serialize(),
            dataType: "json",
            success: function(res) {
                if (res.response == 'success') {
                    e.preventDefault();
                    toastr.success('Berhasil!! <strong> ' + res.last + ' </strong> ' + res.message);
                    initialize();
                } else if (res.response == 'error') {
                    toastr.error(res.message)
                } else if (res.response == 'no_access') {
                    toastr.success(res.message)
                } else if (res.response == 'found') {
                    toastr.error(res.message)
                } else if (res.response == 'not_same') {
                    toastr.error(res.message)
                } else {
                    for (var i = 0; i < res.inputerror.length; i++) {

                        toastr.error(res.error_string[i])
                    }
                }
                $('#btnUpdate').text('Update'); //change button text
                $('#btnUpdate').attr('disabled', false); //set button enable

            },
            error: function(jqXHR, textStatus, errorThrown) {
                toastr.error(res.message)
                $('#btnUpdate').text('Update'); //change button text
                $('#btnUpdate').attr('disabled', false); //set button enable
            }
        });
    })
    $(document).on('click', '#btnHapus', function(e) {

        e.preventDefault();
        $('#btnHapus').text('deleting...');
        $('#btnHapus').attr('disabled', true);
        Swal.fire({
            title: 'Apakah anda yakin?',
            text: "Data tidak bisa di kembalikan!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya!'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: "<?php echo site_url('master/trayek/delete') ?>",
                    type: "POST",
                    data: {
                        id: $('#kode_trayek').val()
                    },
                    dataType: "json",
                    success: function(res) {
                        if (res.response == 'success') {
                            e.preventDefault();
                            toastr.success('Berhasil!! <strong> ' + res.last + ' </strong> ' + res.message);
                            initialize()
                        } else if (res.response == 'found') {
                            toastr.error(res.message)
                        } else if (res.response == 'error') {
                            toastr.error('Ada masalah pada server, silahkan dicoba lagi')
                        } else if (res.response == 'null') {
                            toastr.error('Data tidak ada')
                        } else if (res.response == 'no_access') {
                            toastr.success(res.message)
                        } else {
                            for (var i = 0; i < res.inputerror.length; i++) {
                                $('[id="' + res.inputerror[i] + '"]').parent().parent().addClass('text-danger');
                                $('[id="' + res.inputerror[i] + '"]').next().text(res.error_string[i]);
                            }
                        }
                        $('#btnHapus').text('Hapus'); //change button text
                        $('#btnHapus').attr('disabled', false); //set button enable

                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        toastr.error(res.message)
                        $('#btnHapus').text('Hapus'); //change button text
                        $('#btnHapus').attr('disabled', false); //set button enable

                    }
                });
            } else {
                $('#btnHapus').text('Hapus'); //change button text
                $('#btnHapus').attr('disabled', false); //set button enable
            }
        })
    })
    $(document).on('click', '#btnBatal', function(e) {
        Swal.fire({
            title: 'Apakah anda yakin?',
            text: "Form akan dibatalkan!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Ya!',
            returnFocus: false
        }).then((result) => {
            if (result.isConfirmed) {
                initialize();
            }
        })
    })
</script>

<?= $this->endSection() ?>