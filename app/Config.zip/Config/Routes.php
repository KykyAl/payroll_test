<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('/master/trayek/', 'Master\Trayek::index');
$routes->post('/master/trayek/searchKeberangkatan', 'Master\Trayek::searchKeberangkatan');
$routes->post('/master/trayek/searchKota', 'Master\Trayek::searchKota');
$routes->post('/master/trayek/create', 'Master\Trayek::create');
$routes->post('/master/trayek/ajax_list_trayek', 'Master\Trayek::ajax_list_trayek');
$routes->post('/master/trayek/read', 'Master\Trayek::read');
$routes->post('/master/trayek/readKeberangkatanIn', 'Master\Trayek::readKeberangkatanIn');
$routes->get('/master/trayek/read_last_trayek', 'Master\Trayek::read_last_trayek');
$routes->post('/master/trayek/delete', 'Master\Trayek::delete');
$routes->post('/master/trayek/update', 'Master\Trayek::update');
$routes->get('/master/karyawan', 'Master\Karyawan::index');
$routes->post('/master/karyawan/data', 'Master\Karyawan::get_data');
$routes->post('/master/karyawan/show', 'Master\Karyawan::read');
$routes->post('/master/karyawan/register', 'Master\Register::registerAction');
$routes->get('/master/crew', 'Master\Crew::index');
$routes->post('/master/crew/data', 'Master\Crew::get_data');
$routes->post('/master/crew/show', 'Master\Crew::read');
$routes->post('/master/crew/register', 'Master\Register::registerAction');
$routes->get('/master/operasibis/', 'Master\Operasibis::index');
$routes->post('/master/operasibis/data', 'Master\Operasibis::get_data');
$routes->post('/master/operasibis/show', 'Master\Operasibis::read');




//Routes API
$routes->post('authapi', 'API\AuthController::getToken');
$routes->group('api', ['namespace' => 'App\Controllers\Api'], function ($routes) {


    $routes->post('createkaryawan', 'KaryawanController::create');
    $routes->put('updatekaryawan', 'KaryawanController::update');
    // $routes->delete('deletekaryawan/(:any)/(:any)', 'KaryawanController::delete/$1/$2');
    $routes->delete('deletekaryawan/', 'KaryawanController::delete/');

    $routes->post('createcrew', 'CrewController::create');
    $routes->put('updatecrew', 'CrewController::update');
    $routes->delete('deletecrew/', 'CrewController::delete/');
    $routes->post('createoperasibis', 'OperasibisController::create');
    $routes->put('updateoperasibis', 'OperasibisController::update');
    $routes->delete('deleteoperasibis/', 'OperasibisController::delete/');
});


service('auth')->routes($routes);
